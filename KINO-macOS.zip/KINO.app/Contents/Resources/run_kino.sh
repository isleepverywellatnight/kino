#!/bin/bash
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

# 1. Environnements avec webview déjà installés
if [ -x "$HOME/.kino/venv_mac/bin/python3" ] && "$HOME/.kino/venv_mac/bin/python3" -c "import webview" 2>/dev/null; then
    exec "$HOME/.kino/venv_mac/bin/python3" "$DIR/desktop.py"
fi

if [ -x "$HOME/Downloads/rd-app/.venv_mac/bin/python3" ] && "$HOME/Downloads/rd-app/.venv_mac/bin/python3" -c "import webview" 2>/dev/null; then
    exec "$HOME/Downloads/rd-app/.venv_mac/bin/python3" "$DIR/desktop.py"
fi

# 2. Chercher Python 3 système
PYTHON_BIN=""
for candidate in \
    "/opt/homebrew/bin/python3" \
    "/usr/local/bin/python3" \
    "/usr/bin/python3" \
    "$(which python3 2>/dev/null)"; do
    if [ -x "$candidate" ]; then
        PYTHON_BIN="$candidate"
        break
    fi
done

if [ -z "$PYTHON_BIN" ]; then
    osascript -e 'display alert "Python 3 requis pour KINO" message "Veuillez installer Python 3 sur votre Mac pour utiliser KINO.\n\nTéléchargement gratuit : https://www.python.org/downloads/macos/\nOu avec Homebrew dans le Terminal : brew install python" as critical'
    open "https://www.python.org/downloads/macos/"
    exit 1
fi

if "$PYTHON_BIN" -c "import webview" 2>/dev/null; then
    exec "$PYTHON_BIN" "$DIR/desktop.py"
fi

# 3. Créer ou réparer ~/.kino/venv_mac
USER_VENV="$HOME/.kino/venv_mac"
mkdir -p "$HOME/.kino"

osascript -e 'display notification "Préparation de KINO en cours..." with title "KINO Desktop"' 2>/dev/null || true
if [ ! -d "$USER_VENV" ] || [ ! -f "$USER_VENV/bin/python3" ]; then
    "$PYTHON_BIN" -m venv "$USER_VENV"
fi

"$USER_VENV/bin/pip" install --upgrade pip --quiet
"$USER_VENV/bin/pip" install -r requirements.txt --quiet

exec "$USER_VENV/bin/python3" "$DIR/desktop.py"
