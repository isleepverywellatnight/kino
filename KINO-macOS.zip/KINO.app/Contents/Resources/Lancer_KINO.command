#!/bin/bash
# ===================================================
# KINO Desktop — Lanceur macOS en 1 clic
# ===================================================

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"

echo "=============================================="
echo "          LANCEMENT DE KINO (macOS)           "
echo "=============================================="

# 1. Vérification de Python 3
PYTHON_BIN="python3"
if command -v python3.12 &> /dev/null; then
    PYTHON_BIN="python3.12"
elif command -v python3.13 &> /dev/null; then
    PYTHON_BIN="python3.13"
fi

if ! command -v "$PYTHON_BIN" &> /dev/null; then
    echo "❌ Python 3 n'est pas installé sur votre Mac."
    echo ""
    echo "Pour l'installer facilement :"
    echo "  1) Soit avec Homebrew (recommandé) : brew install python@3.12"
    echo "  2) Soit le site officiel : https://www.python.org/downloads/macos/"
    echo ""
    read -p "Appuyez sur [Entrée] pour quitter..."
    exit 1
fi

# 2. Préparation automatique de l'environnement virtuel macOS
if [ ! -d ".venv_mac" ]; then
    echo "🔧 Première configuration sur votre Mac..."
    echo "📦 Installation des bibliothèques nécessaires (pywebview, WebKit)..."
    "$PYTHON_BIN" -m venv .venv_mac
    source .venv_mac/bin/activate
    pip install --upgrade pip --quiet
    pip install -r requirements.txt --quiet
    echo "✅ Installation réussie !"
    echo ""
else
    source .venv_mac/bin/activate
fi

# 3. Démarrage de l'application
echo "🎬 Démarrage de KINO Desktop..."
python3 desktop.py
